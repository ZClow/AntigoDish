package com.example.a485project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class OrderManagement : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_management)
    }
}